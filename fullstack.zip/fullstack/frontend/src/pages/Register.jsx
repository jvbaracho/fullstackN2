import RegisterForm from '../components/RegisterForm';

export default function Register() {
  return (
    <div>
      <h2>Registro</h2>
      <RegisterForm />
    </div>
  );
}
