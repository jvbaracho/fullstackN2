PORT=5000
MONGO_URI=mongodb+srv://<usuario>:<senha>@cluster.mongodb.net/meubanco
JWT_SECRET=sua_chave_secreta_supersegura
